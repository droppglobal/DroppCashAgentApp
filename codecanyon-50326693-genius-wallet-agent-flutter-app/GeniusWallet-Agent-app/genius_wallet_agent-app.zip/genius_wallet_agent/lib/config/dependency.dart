import 'package:get_it/get_it.dart';
import 'package:injectable/injectable.dart';
import 'package:wallet_agent/config/dependency.config.dart';

//flutter packages pub run build_runner build
GetIt instance = GetIt.instance;

@InjectableInit(
  initializerName: 'init', // default
  preferRelativeImports: true, // default
  asExtension: false, // default
)

void configureInjection() {
  GetIt.I.allowReassignment = true;
  init(instance,environment: Environment.dev);
}
