import '../../../../app_helper/enums.dart';
import '../data/receiver_check.dart';
import '../data/request_money_data.dart';


class CashInState {
  RequestMoneyData? moneyFrom;
  Wallets? selectedWallets;
  ReceiverCheck? receiverCheck;
  PageState pageState;


  CashInState({this.moneyFrom, this.receiverCheck, this.selectedWallets, this.pageState = PageState.Initial});

  CashInState init() {
    return CashInState();
  }

  CashInState clone({RequestMoneyData? moneyFrom, ReceiverCheck? receiverCheck, Wallets? selectedWallets, PageState? pageState}) {
    return CashInState(
      moneyFrom: moneyFrom ?? this.moneyFrom,
      receiverCheck: receiverCheck ?? this.receiverCheck,
      selectedWallets: selectedWallets ?? this.selectedWallets,
      pageState: pageState ?? this.pageState
    );
  }
}
