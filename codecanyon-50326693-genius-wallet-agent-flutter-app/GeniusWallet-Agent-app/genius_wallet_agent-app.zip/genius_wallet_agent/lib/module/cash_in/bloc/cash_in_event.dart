
import '../data/request_money_data.dart';

abstract class CashInEvent {}

class InitEvent extends CashInEvent {}
class SubmitTransfer extends CashInEvent {}
class ChangeWallets extends CashInEvent {
  Wallets? wallets;

  ChangeWallets(this.wallets);
}