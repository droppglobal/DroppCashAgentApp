import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:wallet_agent/Widgets/show_message.dart';
import 'package:wallet_agent/app_helper/extensions.dart';
import 'package:wallet_agent/app_helper/helper.dart';
import 'package:wallet_agent/main.dart';

import '../../../../app_helper/debouncer.dart';
import '../../../../app_helper/enums.dart';
import '../../../../repositories/transfer_repository.dart';
import '../../../../utils/design_component.dart';
import '../view/cash_in_confirmation_sheet.dart';
import 'cash_in_event.dart';
import 'cash_in_state.dart';

class CashInBloc extends Bloc<CashInEvent, CashInState> {
  TransferRepository repository = TransferRepository();
  TextEditingController receiverEmail = TextEditingController();
  TextEditingController amount = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey();
  DeBouncer debouncer = DeBouncer();

  CashInBloc() : super(CashInState().init()) {
    on<InitEvent>(_init);
    on<SubmitTransfer>(_submitData);
    on<ChangeWallets>(_changeWallets);
  }
  @override
  Future<void> close() {
    repository.close();
    return super.close();
  }

  void _init(InitEvent event, Emitter<CashInState> emit) async {
    receiverEmail.addListener(() {
      debouncer.run(() {
        searchData();
      });
    });
    await repository.getRequestMoneyFrom(
      onSuccess: (data){
        emit(state.clone(moneyFrom: data));
      },
      onError: (data){}
    );
  }
  void searchData() {
    state.receiverCheck = null;
    emit(state.clone());
    if(receiverEmail.text.isNotEmpty && Helper.isEmailValid(receiverEmail.text)){
      state.receiverCheck = null;
      repository.checkReceiver(
        email: receiverEmail.text,
        onSuccess: (data){
          emit(state.clone(receiverCheck: data));
        },
        onError: (data){
          emit(state.clone(receiverCheck: data));
        }
      );
    }
  }

  FutureOr<void> _submitData(SubmitTransfer event, Emitter<CashInState> emit) async {
    if(!formKey.currentState!.validate()) return;
    if(state.receiverCheck == null) return;
    Helper.hideKeyboard();
    bool? status = await DesignComponent.showBottomSheetPopup(
        isScrollControlled: true,
        child: CashInConfirmationSheet(
            amount.text.toDouble,
            0,
            state.selectedWallets!.currency!.code!
        )
    );
    if(status != null && status == true) {
      emit(state.clone(pageState: PageState.Loading));
      await repository.submitRequest(
          body: {
            'receiver': receiverEmail.text,
            'wallet_id': state.selectedWallets!.id.toString(),
            'amount': amount.text,
          },
          onSuccess: (data) {
            backPage();
            SuccessMessage(message: data['message']);
          },
          onError: (data) {}
      );
      emit(state.clone(pageState: PageState.Success));
    }
  }

  FutureOr<void> _changeWallets(ChangeWallets event, Emitter<CashInState> emit) {
    emit(state.clone(selectedWallets: event.wallets));
  }
}
