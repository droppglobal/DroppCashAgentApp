import 'package:wallet_agent/app_helper/enums.dart';
import 'package:wallet_agent/data/auth.dart';
import 'package:wallet_agent/module/two_fa_verification/data/two_fa_code.dart';

import '../../../data/user.dart';

class TwoFAVerificationState {
  PageState pageState;
  TwoFaCode? faData;
  User user = Auth.getAuth()!.response!.user!;
  bool verificationLoading = false;


  TwoFAVerificationState({this.pageState = PageState.Initial, this.faData,this.verificationLoading = false});

  TwoFAVerificationState init() {
    return TwoFAVerificationState();
  }

  TwoFAVerificationState clone({PageState? pageState, TwoFaCode? faData, bool? verificationLoading}) {
    return TwoFAVerificationState(
      pageState: pageState ?? this.pageState,
      faData: faData ?? this.faData,
        verificationLoading: verificationLoading ?? this.verificationLoading
    );
  }
}
