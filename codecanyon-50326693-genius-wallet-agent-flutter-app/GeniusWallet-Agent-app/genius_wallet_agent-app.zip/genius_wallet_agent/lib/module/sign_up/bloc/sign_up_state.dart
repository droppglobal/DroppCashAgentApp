import 'dart:io';

import '../../../../app_helper/enums.dart';
import '../../../data/countries.dart';

class SignUpState {
  bool isAgree = true;
  PageState pageState;
  File? nidImage;
  Countries countries = Countries.getCountries()!;
  Country? country;

  SignUpState({this.isAgree = false,this.pageState = PageState.Initial, this.nidImage, this.country});

  SignUpState init() {
    return SignUpState();
  }

  SignUpState clone({bool? isAgree,PageState? state, File? nidImage, Country? country}) {
    return SignUpState(
      isAgree: isAgree ?? this.isAgree,
      pageState: state ?? pageState,
      nidImage: nidImage ?? this.nidImage,
      country: country ?? this.country,
    );
  }
}
