import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_agent/Widgets/divider_list.dart';
import 'package:wallet_agent/app_helper/extensions.dart';
import 'package:wallet_agent/data/auth.dart';
import 'package:wallet_agent/module/main_page/data/withdraw.dart';
import 'package:wallet_agent/module/main_page/view/transaction_details_sheet.dart';
import 'package:wallet_agent/utils/design_component.dart';

import '../../../../Widgets/circular_progress.dart';
import '../../../../Widgets/default_button.dart';
import '../../../../Widgets/network_image.dart';
import '../../../../Widgets/swipe_refresh.dart';
import '../../../../app_helper/enums.dart';
import '../../../../main.dart';
import '../../../../module/main_page/data/drawer_tab.dart';
import '../../../../routes/app_pages.dart';
import '../../../../theme/app_color.dart';
import '../../../../utils/dimension.dart';
import '../../../Widgets/message_dialog.dart';
import '../../../controllers/share_helper.dart';
import '../../../gen/assets.gen.dart';
import '../bloc/main_page_bloc.dart';
import '../bloc/main_page_event.dart';
import '../bloc/main_page_state.dart';
import '../data/dashboard.dart';

class MainPage extends StatelessWidget {
  MainPageBloc? bloc;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => MainPageBloc()..add(InitEvent()),
      child: BlocBuilder<MainPageBloc,MainPageState>(builder: (context,state) => _buildPage(context,state)),
    );
  }

  Widget _buildPage(BuildContext context, MainPageState state) {
    bloc ??= BlocProvider.of<MainPageBloc>(context);
    state.user = Auth.getAuth()!.response!.user;

    return Scaffold(
      key: bloc!.scaffoldKey,
      drawer: drawerView(context,state),
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Column(
            children: [
              Dimension.paddingTop.verticalSpace,
              Padding(
                padding: REdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    InkWell(
                      onTap:(){
                        bloc!.scaffoldKey.currentState!.openDrawer();
                      },
                      child: Assets.icons.menu.svg(height: 24.h, color: AppColor.textColor)
                    ),
                    16.horizontalSpace,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${appLanguage(context).welcome}!',style: appTheme(context).textTheme.bodyMedium,),
                          Text((state.user!.name ?? '').capitalize,style: appTheme(context).textTheme.bodyMedium!.copyWith(
                            fontSize: 20.spMin,
                            fontWeight: Dimension.textSemiBold
                          ),)
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: ()=> goToPage(Routes.EDIT_PROFILE),
                      child: ClipOval(
                        child: CachedImage(
                          imageUrl: state.user!.photo,
                          isProfileImage: true,
                          name: state.user!.name ?? '',
                          height: 40.h,
                          width: 40.h,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              16.verticalSpace,
              /*if(['0','3'].contains(state.user!.status!))
                Padding(
                  padding: REdgeInsets.symmetric(horizontal: 16).copyWith(
                      bottom: 16
                  ),
                  child: DefaultButton(
                    onTap: () async {
                      await goToPage(Routes.KYC_VERIFICATION);
                      state.user = Auth.getAuth()!.response!.user;
                      bloc!.emit(state.clone());
                    },
                    backgroundColor: state.user!.kycStatus == '0' ? AppColor.yellow : AppColor.red,
                    child: Center(child: Text(
                      state.user!.kycStatus == '0' ? appLanguage(context).kyc_info_needed : appLanguage(context).kyc_info_rejected,
                      style: appTheme(context).textTheme.bodyLarge!.copyWith(
                        color: state.user!.kycStatus == '0' ? AppColor.textColor : AppColor.white,
                        fontWeight: Dimension.textMedium
                      ),
                    ))
                  ),
                ),*/
              Expanded(
                child: SwipeRefresh(
                  controller: bloc!.refreshController,
                  onRefresh: ()=>bloc!.add(InitEvent()),
                  child: state.pageState == PageState.Loading ? CircularProgress(height: 1.sh) :
                  ListView(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children: [
                      Column(
                        children: [
                          CarouselSlider.builder(
                            carouselController: bloc!.carouselController,
                            itemCount: state.dashboard?.response?.wallets?.length ?? 0,
                            options: CarouselOptions(
                              autoPlay: false,
                              enlargeCenterPage: true,
                              viewportFraction: 0.9,
                              aspectRatio: 2.1,
                              initialPage: 0,
                              onPageChanged: (index, reason){
                                bloc!.pageIndex.value = index;
                              }
                            ),
                            itemBuilder: (BuildContext context, int index, int pageViewIndex) {
                              Wallets data = state.dashboard!.response!.wallets![index];
                              return Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12.r),
                                  color: AppColor.primary,
                                ),
                                clipBehavior: Clip.antiAlias,
                                child: Container(
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(Assets.images.cardForground.keyName),
                                      fit: BoxFit.cover
                                    )
                                  ),
                                  padding: REdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        height: 60.h,
                                        width: 60.h,
                                        decoration: BoxDecoration(
                                          color: AppColor.white,
                                          shape: BoxShape.circle
                                        ),
                                        alignment: Alignment.center,
                                        child: Text(
                                          data.currency!.symbol ?? '',
                                          style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                              fontSize: 24.spMin,
                                              color: AppColor.primary
                                          ),
                                        ),
                                      ),
                                      Expanded(child: Container()),
                                      Text('${data.currency!.symbol} ${(data.balance ?? '').toDouble.toStringAsFixed(2)}',style: appTheme(context).textTheme.bodyMedium!.copyWith(
                                        fontSize: 24.spMin,
                                        fontWeight: Dimension.textSemiBold,
                                        color: AppColor.white
                                      ),),
                                      4.verticalSpace,
                                      Text(
                                        data.currency?.code ?? '',
                                        style: appTheme(context).textTheme.bodyLarge!.copyWith(
                                          color: AppColor.white
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                          12.verticalSpace,
                          ValueListenableBuilder<int>(
                            valueListenable: bloc!.pageIndex,
                            builder: (context, value, child) {
                              return Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: (state.dashboard?.response?.wallets ?? []).asMap().map((key, value2) => MapEntry(key,
                                    GestureDetector(
                                      onTap: () => bloc!.carouselController.animateToPage(key),
                                      child: Container(
                                        width: (value == key ? 20 : 8).h,
                                        height: 6.h,
                                        margin: REdgeInsets.only(right: 6.0),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(4.r),
                                          color: AppColor.primary.withOpacity(value == key ? 1 : 0.1)
                                        ),
                                      ),
                                    )
                                )).values.toList(),
                              );
                            }
                          )
                        ],
                      ),
                      16.verticalSpace,
                      Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r)
                        ),
                        margin: REdgeInsets.symmetric(horizontal: 16).copyWith(
                          bottom: 16
                        ),
                        color: AppColor.white,
                        elevation: 10,
                        child: Padding(
                          padding: REdgeInsets.symmetric(horizontal: 19, vertical: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                appLanguage(context).quick_action,
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                  fontSize: 24.spMin,
                                  fontWeight: Dimension.textSemiBold
                                ),
                              ),
                              8.verticalSpace,
                              Divider(thickness: 1,height: 1,color: AppColor.dividerColor,),
                              16.verticalSpace,
                              Row(
                                children: [
                                  Expanded(
                                    child: InkWell(
                                      onTap: ()=> goToPage(Routes.QR_PAGE),
                                      child: Column(
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                                color: const Color(0xFF00E0EE).withOpacity(0.1),
                                                borderRadius: BorderRadius.circular(8.r)
                                            ),
                                            padding: REdgeInsets.all(16),
                                            child: Assets.icons.barcode.svg(height: 32.h,color: const Color(0xFF00E0EE)),
                                          ),
                                          8.verticalSpace,
                                          Text(
                                            appLanguage(context).qr_code,
                                            style: appTheme(context).textTheme.bodyLarge,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      onTap: ()=> goToPage(Routes.CASH_IN),
                                      child: Column(
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                                color: const Color(0xFFF76707).withOpacity(0.2),
                                                borderRadius: BorderRadius.circular(8.r)
                                            ),
                                            padding: REdgeInsets.all(16),
                                            child: Assets.icons.cashIn.svg(height: 32.h,color: const Color(0xFFF76707)),
                                          ),
                                          8.verticalSpace,
                                          Text(
                                            appLanguage(context).cash_in,
                                            style: appTheme(context).textTheme.bodyLarge,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      onTap: ()=> goToPage(Routes.ADD_WITHDRAW),
                                      child: Column(
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                                color: const Color(0xFF2FB344).withOpacity(0.2),
                                                borderRadius: BorderRadius.circular(8.r)
                                            ),
                                            padding: REdgeInsets.all(16),
                                            child: Assets.icons.withdraw.svg(height: 32.h,color: const Color(0xFF2FB344)),
                                          ),
                                          8.verticalSpace,
                                          Text(
                                            appLanguage(context).withdraw,
                                            style: appTheme(context).textTheme.bodyLarge,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      onTap: ()=> bloc!.scaffoldKey.currentState!.openDrawer(),
                                      child: Column(
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                                color: const Color(0xFF4299E1).withOpacity(0.2),
                                                borderRadius: BorderRadius.circular(8.r)
                                            ),
                                            padding: REdgeInsets.all(16),
                                            child: Assets.icons.more.svg(height: 32.h,color: const Color(0xFF4299E1)),
                                          ),
                                          8.verticalSpace,
                                          Text(
                                            appLanguage(context).more,
                                            style: appTheme(context).textTheme.bodyLarge,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                      Container(
                        color: AppColor.white,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            32.verticalSpace,
                            Padding(
                              padding: REdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                appLanguage(context).recent_transaction,
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                    fontWeight: Dimension.textSemiBold,
                                    fontSize: 24.spMin
                                ),
                              ),
                            ),
                            12.verticalSpace,
                            ListView.builder(
                                itemCount: state.dashboard?.response?.transactions?.length ?? 0,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                padding: REdgeInsets.symmetric(horizontal: 16),
                                itemBuilder: (ctx,index){
                                  TransactionData data = state.dashboard!.response!.transactions![index];
                                  return DividerList(
                                    child: InkWell(
                                      onTap: ()=> showTransactionDetails(data),
                                      child: Padding(
                                        padding: REdgeInsets.symmetric(vertical: 12),
                                        child: Row(
                                          children: [
                                            Container(
                                              height: 40.h,
                                              width: 40.h,
                                              decoration: BoxDecoration(
                                                color: AppColor.textFieldBackground,
                                                shape: BoxShape.circle
                                              ),
                                              alignment: Alignment.center,
                                              child: data.remark!.getIcon(),
                                            ),
                                            8.horizontalSpace,
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    (data.remark ?? '').replaceAll('_', ' ').capitalize,
                                                    style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                      fontWeight: Dimension.textMedium
                                                    ),
                                                  ),
                                                  4.verticalSpace,
                                                  Text(
                                                    data.trnx ?? '',
                                                    style: appTheme(context).textTheme.bodyMedium,
                                                  )
                                                ],
                                              ),
                                            ),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              children: [
                                                Text(
                                                  '${data.type ?? ''} ${data.currency ?? ''}${(data.amount ?? '').toDouble.toStringAsFixed(2)}',
                                                  style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                    fontWeight: Dimension.textMedium,
                                                    color: data.type == '-' ? AppColor.red : AppColor.green
                                                  ),
                                                ),
                                                4.verticalSpace,
                                                Text(
                                                  data.createdAt ?? '',
                                                  style: appTheme(context).textTheme.bodyMedium,
                                                )
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                }
                            ),
                            16.verticalSpace,
                            Center(
                              child: DefaultButton(
                                onTap: ()=>goToPage(Routes.TRANSACTIONS),
                                padding: REdgeInsets.symmetric(horizontal: 16,vertical:10),
                                buttonType: ButtonType.BORDER,
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      appLanguage(context).see_all_transactions,
                                      style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                        fontWeight: Dimension.textRegular,
                                        color: AppColor.primary
                                      ),
                                    ),
                                    8.horizontalSpace,
                                    Assets.icons.forword.svg(color: AppColor.primary),
                                  ],
                                )
                              ),
                            ),
                            32.verticalSpace,
                            Padding(
                              padding: REdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                appLanguage(context).recent_withdraws,
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                    fontWeight: Dimension.textSemiBold,
                                    fontSize: 24.spMin
                                ),
                              ),
                            ),
                            12.verticalSpace,
                            ListView.builder(
                                itemCount: state.dashboard?.response?.recentWithdraw?.length ?? 0,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                padding: REdgeInsets.symmetric(horizontal: 16),
                                itemBuilder: (ctx,index){
                                  Withdraw data = state.dashboard!.response!.recentWithdraw![index];
                                  return Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.r)
                                    ),
                                    margin: REdgeInsets.only(bottom: 8),
                                    child: ExpansionTile(
                                      tilePadding: REdgeInsets.symmetric(horizontal: 16).copyWith(
                                        right: 8
                                      ),
                                      childrenPadding: REdgeInsets.symmetric(horizontal: 16).copyWith(
                                        bottom: 16
                                      ),
                                      iconColor: AppColor.primary,
                                      title: Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              data.trx ?? '',
                                              style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                fontWeight: Dimension.textMedium
                                              ),
                                            ),
                                          ),
                                          Text(
                                            '${(data.amount ?? '0').toDouble.toStringAsFixed(1)} ${data.currency?.code ?? ''}',
                                            style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                fontWeight: Dimension.textRegular
                                            ),
                                          ),
                                        ],
                                      ),
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                appLanguage(context).charge,
                                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                    fontWeight: Dimension.textMedium
                                                ),
                                              ),
                                            ),
                                            Text(
                                              '${(data.charge ?? '0').toDouble.toStringAsFixed(1)} ${data.currency?.code ?? ''}',
                                              style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                  fontWeight: Dimension.textRegular
                                              ),
                                            ),
                                          ],
                                        ),
                                        8.verticalSpace,
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                appLanguage(context).total_amount,
                                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                    fontWeight: Dimension.textMedium
                                                ),
                                              ),
                                            ),
                                            Text(
                                              '${(data.totalAmount ?? '0').toDouble.toStringAsFixed(1)} ${data.currency?.code ?? ''}',
                                              style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                  fontWeight: Dimension.textRegular
                                              ),
                                            ),
                                          ],
                                        ),
                                        8.verticalSpace,
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                appLanguage(context).method,
                                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                    fontWeight: Dimension.textMedium
                                                ),
                                              ),
                                            ),
                                            Text(
                                              data.methodName ?? '',
                                              style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                  fontWeight: Dimension.textRegular
                                              ),
                                            ),
                                          ],
                                        ),
                                        8.verticalSpace,
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                appLanguage(context).state,
                                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                    fontWeight: Dimension.textMedium
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(20.r),
                                                  color: data.status!.statusColor
                                              ),
                                              padding: REdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                              child: Text(
                                                (data.status ?? '0').statusName,
                                                style: appTheme(context).textTheme.bodySmall
                                              ),
                                            )
                                          ],
                                        ),
                                        8.verticalSpace,
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                appLanguage(context).date,
                                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                    fontWeight: Dimension.textMedium
                                                ),
                                              ),
                                            ),
                                            Text(
                                              (data.createdAt ?? '').toDate('dd MMM yyyy -- hh:mm a'),
                                              style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                                  fontWeight: Dimension.textRegular
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                }
                            ),
                            16.verticalSpace,
                            Center(
                              child: DefaultButton(
                                onTap: ()=>goToPage(Routes.WITHDRAW_LIST),
                                padding: REdgeInsets.symmetric(horizontal: 16,vertical:10),
                                buttonType: ButtonType.BORDER,
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      appLanguage(context).see_all_withdraws,
                                      style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                        fontWeight: Dimension.textRegular,
                                        color: AppColor.primary
                                      ),
                                    ),
                                    8.horizontalSpace,
                                    Assets.icons.forword.svg(color: AppColor.primary),
                                  ],
                                )
                              ),
                            ),
                            Dimension.bottomSpace
                          ],
                        ),
                      ),
                    ],
                  )
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget singleSection({
    required String title,
    required String data,
    required Color color,
    required IconData icon,
    double? iconSize,
    bool isSwitched = false,
    EdgeInsetsGeometry? padding,
    IconButton? tileButton
  }){
    return Card(
      margin: padding ?? EdgeInsets.symmetric(horizontal: 16.r).copyWith(top: 8.r),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(2)
      ),
      elevation: 4,
      clipBehavior: Clip.antiAlias,
      child: Container(
        padding: EdgeInsets.all(8.r),
        child: Row(
          children: [
            Container(
              height: 40.r,
              width: 40.r,
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(4.r),
                border: Border.all(width: 1,color: color.withOpacity(0.5)),
              ),
              padding: EdgeInsets.all(8.r),
              margin: EdgeInsets.only(right: 8.r),
              child: Icon(icon,color: color,size: iconSize ?? 24.r,),
            ),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: !isSwitched ? [
                Text(title ,style: appTheme().textTheme.bodySmall!.copyWith(fontWeight: Dimension.textMedium,color: AppColor.grey),),
                Text(data ,style: appTheme().textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textSemiBold),),
              ] : [
                Text(data ,style: appTheme().textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textSemiBold),),
                Text(title ,style: appTheme().textTheme.bodySmall!.copyWith(fontWeight: Dimension.textMedium,color: AppColor.grey),),
              ],
            )),
            if(tileButton!=null)
              tileButton
          ],
        ),
      ),
    );
  }

  Widget drawerView(BuildContext context, MainPageState state) {
    return Drawer(
      backgroundColor: AppColor.white,
      elevation: 0,
      width: 0.8.sw,
      child: Column(
        children: [
          DrawerHeader(
            duration: const Duration(seconds: 1),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(Assets.images.splashScreen.keyName),
                fit: BoxFit.cover
              )
            ),
            child: InkWell(
              onTap: ()=> navigatePage(Routes.EDIT_PROFILE,null),
              child: Stack(
                children: [
                  Row(
                    children: [
                      ClipOval(
                        child: CachedImage(
                          imageUrl: state.user?.photo ?? '',
                          isProfileImage: true,
                          height: 60.h,
                          width: 60.h,
                        ),
                      ),
                      8.horizontalSpace,
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text((state.user?.name ?? '').capitalize,style: appTheme(context).textTheme.headlineLarge!.copyWith(
                              fontSize: 24.spMin,
                              color: AppColor.white
                            ),),
                            Text(state.user?.email ?? '',style: appTheme(context).textTheme.bodyLarge!.copyWith(color: AppColor.textColor2,fontWeight: Dimension.textMedium),),
                          ],
                        ),
                      )
                    ],
                  ),
                  Positioned(
                    top: -8,
                    right: -8,
                    child: IconButton(
                      onPressed: (){
                        bloc!.scaffoldKey.currentState!.closeDrawer();
                      },
                      icon: Icon(Icons.close,color: AppColor.white,size: 32,),
                    ),
                  )
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: REdgeInsets.symmetric(horizontal: 16),
                  itemCount: state.drawerTabs.length,
                  itemBuilder: (ctx,index){
                    DrawerTab tab = state.drawerTabs[index];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        24.verticalSpace,
                        Text(
                          tab.title,
                          style: appTheme(context).textTheme.headlineLarge!.copyWith(
                            fontWeight: Dimension.textSemiBold,
                            fontSize: 24.spMin
                          ),
                        ),
                        24.verticalSpace,
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.zero,
                          itemCount: tab.tabs.length,
                          itemBuilder: (ctx, position){
                            SubTab subTab = tab.tabs[position];
                            return InkWell(
                              onTap: ()=>navigatePage(subTab.route,subTab.arguments),
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 8.r),
                                child: Row(
                                  children: [
                                    Container(
                                      height: 40.w,
                                      width: 40.w,
                                      decoration: BoxDecoration(
                                        color: AppColor.textFieldBackground,
                                        shape: BoxShape.circle
                                      ),
                                      padding: REdgeInsets.all(8),
                                      child: SvgPicture.asset(subTab.icon,color: AppColor.iconColor,),
                                    ),
                                    16.horizontalSpace,
                                    Expanded(
                                      child: Text(subTab.title,style: appTheme(context).textTheme.headlineMedium!.copyWith(
                                          fontWeight: Dimension.textMedium,
                                          fontSize: 20.spMin
                                      ),),
                                    ),
                                    Assets.icons.forword.svg(color: AppColor.primary),
                                    8.horizontalSpace
                                  ],
                                ),
                              ),
                            );
                          }
                        ),
                      ],
                    );
                  },
                ),
                InkWell(
                  onTap: ()=>logoutDialog(),
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 8.r, horizontal: 16),
                    child: Row(
                      children: [
                        Container(
                          height: 40.w,
                          width: 40.w,
                          decoration: BoxDecoration(
                              color: AppColor.textFieldBackground,
                              shape: BoxShape.circle
                          ),
                          padding: REdgeInsets.all(8),
                          child: SvgPicture.asset(Assets.icons.logout.keyName,color: AppColor.iconColor,),
                        ),
                        16.horizontalSpace,
                        Expanded(
                          child: Text(appLanguage(context).logout,style: appTheme(context).textTheme.headlineMedium!.copyWith(
                              fontWeight: Dimension.textMedium,
                              fontSize: 20.spMin
                          ),),
                        ),
                        Assets.icons.forword.svg(color: AppColor.primary),
                        8.horizontalSpace
                      ],
                    ),
                  ),
                ),
                Dimension.bottomSpace
              ],
            ),
          )
        ],
      ),
    );
  }
  void logoutDialog(){
    bloc!.scaffoldKey.currentState!.closeDrawer();
    MessageDialog(
        title: appLanguage().logout,
        message: appLanguage().are_you_sure_you_want_to_logout,
        isConfirmDialog: true,
        onTap: (state){
          backPage();
          if(state){
            ShareHelper.logOut();
          }
        }
    );
  }

  void showTransactionDetails(TransactionData data){
    DesignComponent.showBottomSheetPopup(child: TransactionDetailsSheet(data));
  }

  void navigatePage(String? route,dynamic arguments){
    bloc!.scaffoldKey.currentState!.closeDrawer();
    if(route!=null){
      goToPage(route,arguments: arguments);
    }
  }

}

