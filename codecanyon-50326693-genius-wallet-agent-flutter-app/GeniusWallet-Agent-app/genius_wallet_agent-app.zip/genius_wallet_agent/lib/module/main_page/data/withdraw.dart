class Withdraw {
  Withdraw({
      this.id, 
      this.trx, 
      this.userId, 
      this.merchantId, 
      this.agentId, 
      this.methodId, 
      this.methodName,
      this.currencyId,
      this.amount, 
      this.charge, 
      this.totalAmount, 
      this.userData, 
      this.status, 
      this.rejectReason, 
      this.createdAt, 
      this.updatedAt, 
      this.currency,});

  Withdraw.fromJson(dynamic json) {
    id = json['id'];
    trx = json['trx'];
    userId = json['user_id'];
    merchantId = json['merchant_id'];
    agentId = json['agent_id'];
    methodId = json['method_id'];
    methodName = json['method']['name'];
    currencyId = json['currency_id'];
    amount = json['amount'];
    charge = json['charge'];
    totalAmount = json['total_amount'];
    userData = json['user_data'];
    status = json['status'];
    rejectReason = json['reject_reason'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    currency = json['currency'] != null ? Currency.fromJson(json['currency']) : null;
  }
  num? id;
  String? trx;
  dynamic userId;
  dynamic merchantId;
  String? agentId;
  String? methodId;
  String? currencyId;
  String? amount;
  String? charge;
  String? totalAmount;
  String? userData;
  String? methodName;
  String? status;
  dynamic rejectReason;
  String? createdAt;
  String? updatedAt;
  Currency? currency;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['trx'] = trx;
    map['user_id'] = userId;
    map['merchant_id'] = merchantId;
    map['agent_id'] = agentId;
    map['method_id'] = methodId;
    map['currency_id'] = currencyId;
    map['amount'] = amount;
    map['charge'] = charge;
    map['total_amount'] = totalAmount;
    map['user_data'] = userData;
    map['status'] = status;
    map['reject_reason'] = rejectReason;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    if (currency != null) {
      map['currency'] = currency?.toJson();
    }
    return map;
  }

}

class Currency {
  Currency({
      this.id, 
      this.defaultValue,
      this.symbol, 
      this.code, 
      this.currName, 
      this.type, 
      this.status, 
      this.rate, 
      this.createdAt, 
      this.updatedAt,});

  Currency.fromJson(dynamic json) {
    id = json['id'];
    defaultValue = json['default'];
    symbol = json['symbol'];
    code = json['code'];
    currName = json['curr_name'];
    type = json['type'];
    status = json['status'];
    rate = json['rate'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }
  num? id;
  String? defaultValue;
  String? symbol;
  String? code;
  String? currName;
  String? type;
  String? status;
  String? rate;
  String? createdAt;
  String? updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['default'] = defaultValue;
    map['symbol'] = symbol;
    map['code'] = code;
    map['curr_name'] = currName;
    map['type'] = type;
    map['status'] = status;
    map['rate'] = rate;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }

}