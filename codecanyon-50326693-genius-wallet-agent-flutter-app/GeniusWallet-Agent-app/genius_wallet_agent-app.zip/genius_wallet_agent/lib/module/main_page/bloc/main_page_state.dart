import 'package:wallet_agent/data/module.dart';
import 'package:wallet_agent/data/settings.dart';
import 'package:wallet_agent/gen/assets.gen.dart';

import '../../../../app_helper/enums.dart';
import '../../../../data/auth.dart';
import '../../../../main.dart';
import '../../../../module/main_page/data/dashboard.dart';
import '../../../../routes/app_pages.dart';
import '../../../data/user.dart';
import '../data/drawer_tab.dart';

class MainPageState {
  PageState pageState;
  Dashboard? dashboard;
  User? user = Auth.getAuth()!.response!.user!;
  Settings? settings;
  Module? module = Module.getModule();
  List<DrawerTab> drawerTabs = [];


  MainPageState({
    this.dashboard,
    this.pageState = PageState.Loading,
    this.user,
    this.settings
  }){
    user = Auth.getAuth()!.response!.user!;
    drawerTabs = [
      DrawerTab(
          title: appLanguage().dashboard,
          tabs: [
            SubTab(
                title: appLanguage().transactions,
                icon: Assets.icons.exchangeMoney.keyName,
                route: Routes.TRANSACTIONS
            ),
            SubTab(
                title: appLanguage().qr_code,
                icon: Assets.icons.barcode.keyName,
                route: Routes.QR_PAGE
            ),
            SubTab(
                title: appLanguage().fund_request,
                icon: Assets.icons.deposit.keyName,
                route: Routes.FUND_REQUEST_LIST
            ),
            SubTab(
                title: appLanguage().user_cash_in,
                icon: Assets.icons.cashIn.keyName,
                route: Routes.CASH_IN
            ),
          ]
      ),
      DrawerTab( //Done
          title: appLanguage().withdraw,
          tabs: [
            SubTab(
                title: appLanguage().withdraw_money,
                icon: Assets.icons.withdraw.keyName,
                route: Routes.ADD_WITHDRAW
            ),
            SubTab(
                title: appLanguage().withdraw_history,
                icon: Assets.icons.clock.keyName,
                route: Routes.WITHDRAW_LIST
            ),
          ]
      ),
      DrawerTab( //Done
          title: appLanguage().settings,
          tabs: [
            SubTab(
              title: appLanguage().profile_setting,
              icon: Assets.icons.user.keyName,
              route: Routes.EDIT_PROFILE
            ),
            SubTab(
              title: appLanguage().change_password,
              icon: Assets.icons.addVoucher.keyName,
              route: Routes.CHANGE_PASSWORD
            ),
            SubTab(
              title: appLanguage().two_step_security,
              icon: Assets.icons.security.keyName,
              route: Routes.TWO_FA_VERIFICATION
            ),
            SubTab(
              title: appLanguage().support_ticket,
              icon: Assets.icons.support.keyName,
              route: Routes.SUPPORT_PAGES
            )
          ]
      ),
    ];
  }

  MainPageState init() {
    return MainPageState();
  }

  MainPageState clone({Dashboard? dashboard,PageState? pageState, User? user, Settings? settings}) {
    return MainPageState(
      dashboard: dashboard ?? this.dashboard,
      pageState: pageState ?? this.pageState,
      user: user ?? this.user,
      settings: settings ?? this.settings
    );
  }
}
