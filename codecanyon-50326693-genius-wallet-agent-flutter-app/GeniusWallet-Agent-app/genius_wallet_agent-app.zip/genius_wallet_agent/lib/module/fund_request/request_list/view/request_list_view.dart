import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:wallet_agent/Widgets/circular_progress.dart';
import 'package:wallet_agent/Widgets/default_appbar.dart';
import 'package:wallet_agent/Widgets/empty_page.dart';
import 'package:wallet_agent/Widgets/message_dialog.dart';
import 'package:wallet_agent/Widgets/swipe_refresh.dart';
import 'package:wallet_agent/app_helper/enums.dart';
import 'package:wallet_agent/app_helper/extensions.dart';
import 'package:wallet_agent/main.dart';
import 'package:wallet_agent/module/fund_request/request_list/data/fund_list.dart';

import '../../../../gen/assets.gen.dart';
import '../../../../theme/app_color.dart';
import '../../../../utils/dimension.dart';
import '../bloc/request_list_bloc.dart';
import '../bloc/request_list_event.dart';
import '../bloc/request_list_state.dart';

class RequestListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => RequestListBloc()..add(InitEvent()),
      child: BlocBuilder<RequestListBloc,RequestListState>(builder: (context,state) => _buildPage(context,state)),
    );
  }

  Widget _buildPage(BuildContext context, RequestListState state) {
    final bloc = BlocProvider.of<RequestListBloc>(context);
    return Scaffold(
      appBar: DefaultAppbar(
        title: appLanguage(context).fund_request
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: ()=> bloc.add(AddRequest()),
        backgroundColor: AppColor.primary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.r)
        ),
        icon: Icon(Icons.add),
        label: Text(
          appLanguage(context).fund_request,
          style: appTheme(context).textTheme.headlineLarge!.copyWith(
            color: AppColor.white
          ),
        )
      ),
      body: SwipeRefresh(
        controller: bloc.refreshController,
        onRefresh: (){
          bloc.add(InitEvent());
          bloc.add(GetData());
        },
        onLoading: ()=>bloc.add(GetData()),
        child: state.transfers == null || state.pageState != PageState.Success ? CircularProgress(height: 1.sh) : state.transfers!.response!.requests!.data!.isNotEmpty ?
        ListView.builder(
            itemCount: state.transfers!.response!.requests!.data!.length,
            shrinkWrap: true,
            padding: REdgeInsets.symmetric(horizontal: 16),
            itemBuilder: (ctx,index){
              FundData data = state.transfers!.response!.requests!.data![index];
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.r),
                ),
                color: AppColor.white,
                margin: REdgeInsets.only(bottom: 16,top: index == 0 ? 16 : 0),
                child: ExpansionTile(
                    childrenPadding: EdgeInsets.symmetric(horizontal: 16.r).copyWith(bottom: 8.r),
                    tilePadding: EdgeInsets.only(left: 16.r,right: 8.r),
                    collapsedIconColor: AppColor.iconColor,
                    iconColor: AppColor.iconColor,
                    title: Row(
                      children: [
                        Expanded(
                            child: Text(
                              data.uniqueCode ?? '',
                              style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textMedium),
                            )
                        ),
                        Text(
                          (data.amount ?? '0').toDouble.toStringAsFixed(1),
                          style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textMedium),
                        )
                      ],
                    ),
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                                appLanguage(context).currency.toUpperCase(),
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textRegular),
                              )
                          ),
                          Text(
                            data.currencyCode ?? '',
                            style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textRegular),
                          )
                        ],
                      ),
                      8.verticalSpace,
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                                appLanguage(context).state.toUpperCase(),
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textRegular),
                              )
                          ),
                          InkWell(
                            onTap: (){
                              if(data.status == "2"){
                                MessageDialog(
                                  title: appLanguage(context).reject_reasons,
                                  message: data.rejectReason ?? ''
                                );
                              }
                            },
                            child: Row(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20.r),
                                      color: data.status!.statusColor
                                  ),
                                  padding: REdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                  child: Text(
                                      data.status!.statusName.toUpperCase(),
                                      style: appTheme().textTheme.bodySmall
                                  ),
                                ),
                                if(data.status == "2")
                                  Icon(Icons.info,color: AppColor.textColor,)
                              ],
                            ),
                          ),
                        ],
                      ),
                      8.verticalSpace,
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                                appLanguage(context).collection_status.toUpperCase(),
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textRegular),
                              )
                          ),
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20.r),
                                color: data.collect!.statusColor
                            ),
                            padding: REdgeInsets.symmetric(horizontal: 8, vertical: 6),
                            child: Text(
                                data.collect!.collectionStatusName.toUpperCase(),
                                style: appTheme().textTheme.bodySmall
                            ),
                          )
                        ],
                      ),
                      8.verticalSpace,
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                                appLanguage(context).date.toUpperCase(),
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textRegular),
                              )
                          ),
                          Text(
                            DateFormat('dd MMM yyyy -- hh:mm a').format(DateTime.parse(data.createdAt ?? '')),
                            style: appTheme(context).textTheme.headlineLarge!.copyWith(fontWeight: Dimension.textRegular),
                          )
                        ],
                      ),
                      8.verticalSpace,
                    ]
                ),
              );
            }
        ) : EmptyPage(message: appLanguage(context).noDataHere, image: Assets.images.notFound.keyName)
      ),
    );
  }
}

