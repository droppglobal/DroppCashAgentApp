import 'package:wallet_agent/module/fund_request/request_list/data/fund_list.dart';

import '../../../../app_helper/enums.dart';

class RequestListState {
  FundList? transfers;
  PageState pageState;


  RequestListState({this.transfers, this.pageState = PageState.Loading});

  RequestListState init() {
    return RequestListState();
  }

  RequestListState clone({FundList? transfers, PageState? pageState}) {
    return RequestListState(
      pageState: pageState ?? this.pageState,
      transfers: transfers ?? this.transfers
    );
  }
}
