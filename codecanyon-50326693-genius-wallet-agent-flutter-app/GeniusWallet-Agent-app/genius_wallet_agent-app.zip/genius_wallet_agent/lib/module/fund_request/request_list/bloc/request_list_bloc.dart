import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:wallet_agent/Widgets/show_message.dart';
import 'package:wallet_agent/repositories/fund_repository.dart';
import 'package:wallet_agent/utils/design_component.dart';

import '../../../../app_helper/enums.dart';
import '../../../../utils/url.dart';
import '../view/add_request_sheet.dart';
import 'request_list_event.dart';
import 'request_list_state.dart';

class RequestListBloc extends Bloc<RequestListEvent, RequestListState> {
  FundRepository repository = FundRepository();
  RefreshController refreshController = RefreshController(initialRefresh: true);
  String? url;

  RequestListBloc() : super(RequestListState().init()) {
    on<InitEvent>(_init);
    on<GetData>(_getData);
    on<AddRequest>(_addRequest);
  }

  @override
  Future<void> close() {
    repository.close();
    return super.close();
  }

  void _init(InitEvent event, Emitter<RequestListState> emit) async {
    state.transfers = null;
    emit(state.clone());
    url = URL.fundsList;
  }

  FutureOr<void> _getData(GetData event, Emitter<RequestListState> emit) async {
    if(url == null){
      refreshController.loadNoData();
      return;
    }
    await repository.getFundList(
      url: url,
      onSuccess: (data){
        url = data.response!.requests!.nextPageUrl;
        if(state.transfers!=null){
          state.transfers!.response!.requests!.data!.addAll(data.response!.requests!.data!);
          emit(state.clone(pageState: PageState.Success));
        } else {
          emit(state.clone(pageState: PageState.Success, transfers: data));
        }
      },
      onError:(data){}
    );
    refreshController.refreshCompleted();
    refreshController.loadComplete();
  }

  FutureOr<void> _addRequest(AddRequest event, Emitter<RequestListState> emit) async {
    var data = await DesignComponent.showBottomSheetPopup(
      isScrollControlled: true,
      child: CreateRequestSheet(this)
    );
    if(data != null){
      repository.submitFundData(
        body: data,
        onSuccess: (data){
          SuccessMessage(message: data['message']);
          refreshController.requestRefresh();
        },
        onError: (data){}
      );
    }
  }
}
