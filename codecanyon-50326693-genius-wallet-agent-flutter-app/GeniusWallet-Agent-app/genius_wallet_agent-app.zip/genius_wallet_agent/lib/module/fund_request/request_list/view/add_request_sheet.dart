import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:wallet_agent/Widgets/default_button.dart';
import 'package:wallet_agent/Widgets/default_dropdown.dart';
import 'package:wallet_agent/Widgets/default_textfield.dart';
import 'package:wallet_agent/module/fund_request/request_list/bloc/request_list_state.dart';
import 'package:wallet_agent/module/fund_request/request_list/data/fund_list.dart';

import '../../../../main.dart';
import '../../../../theme/app_color.dart';
import '../../../../utils/dimension.dart';
import '../bloc/request_list_bloc.dart';

class CreateRequestSheet extends StatefulWidget {
  final RequestListBloc bloc;
  const CreateRequestSheet(this.bloc,{super.key});

  @override
  State<CreateRequestSheet> createState() => _CreateRequestSheetState();
}

class _CreateRequestSheetState extends State<CreateRequestSheet> {
  GlobalKey<FormState> fromKey = GlobalKey();
  Currencies? selectedCurrency;
  TextEditingController amount = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RequestListBloc, RequestListState>(
      bloc: widget.bloc,
      builder: (context, state) {
        return Form(
          key: fromKey,
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadiusDirectional.only(
                topEnd: Radius.circular(20.r),
                topStart: Radius.circular(20.r),
              ),
              color: AppColor.white,
            ),
            padding: REdgeInsets.only(bottom: MediaQuery
                .of(context)
                .viewInsets
                .bottom),
            child: Stack(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    16.verticalSpace,
                    Text(
                      appLanguage(context).fund_request,
                      style: appTheme(context).textTheme.headlineLarge!.copyWith(
                          fontSize: 20.spMin
                      ),
                    ),
                    16.verticalSpace,
                    Padding(
                      padding: REdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          DefaultTextField(
                            controller: amount,
                            label: appLanguage(context).request_amount,
                            hint: appLanguage(context).request_amount,
                            labelAsTitle: true,
                            textInputType: const TextInputType.numberWithOptions(decimal: true,),
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                          ),
                          16.verticalSpace,
                          DefaultDropDown<Currencies>(
                            items: state.transfers!.response!.currencies!,
                            labelAsTitle: true,
                            label: appLanguage(context).select_currency,
                            hint: appLanguage(context).select_currency,
                            itemAsString: (value)=> value.code ?? '',
                            compareFn: (a,b)=> a.id == b.id,
                            onChanged: (value){
                              selectedCurrency = value;
                            },
                          ),
                          16.verticalSpace,
                          DefaultButton(
                            onTap: (){
                              if(fromKey.currentState!.validate()) {
                                backPage(<String, String>{
                                  'amount': amount.text,
                                  'currency': selectedCurrency!.id!.toString(),
                                });
                              }
                            },
                            child: Center(
                              child: Text(
                                appLanguage(context).submit,
                                style: appTheme(context).textTheme.headlineLarge!.copyWith(
                                  fontWeight: Dimension.textSemiBold,
                                  fontSize: 17.spMin,
                                  color: AppColor.white
                                ),
                              )
                            )
                          )
                        ],
                      ),
                    ),
                    Dimension.bottomSpace
                  ],
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: IconButton(
                      onPressed: () => backPage(),
                      icon: Icon(Icons.close_rounded,
                          color: AppColor.iconColor)),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
