

abstract class RequestListEvent {}

class InitEvent extends RequestListEvent {}
class GetData extends RequestListEvent {}
class AddRequest extends RequestListEvent {}