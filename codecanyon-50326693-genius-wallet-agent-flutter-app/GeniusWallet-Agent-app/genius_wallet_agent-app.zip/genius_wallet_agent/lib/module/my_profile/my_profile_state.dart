import 'dart:io';

import '../../../../app_helper/enums.dart';
import '../../../../data/auth.dart';
import '../../data/countries.dart';

class MyProfileState {
  Auth? auth;
  PageState pageState;
  File? image;
  Countries countries = Countries.getCountries()!;
  Country? country;


  MyProfileState({this.pageState = PageState.Initial,this.auth, this.image, this.country});

  MyProfileState init() {
    return MyProfileState(
      auth: Auth.getAuth()
    );
  }

  MyProfileState clone({PageState? pageState,Auth? auth, File? image, Country? country}) {
    return MyProfileState(
      pageState: pageState ?? this.pageState,
      auth: auth ?? this.auth,
      image: image ?? this.image,
      country: country ?? this.country
    );
  }
}
