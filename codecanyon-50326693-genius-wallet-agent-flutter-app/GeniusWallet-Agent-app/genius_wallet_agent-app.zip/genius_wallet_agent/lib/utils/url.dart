

class URL {
    static const String baseUrl = "https://cleantech.geniusocean.net/wallet-laravel-10/";
    static const String googleAuthenticatorAppLinkAndroid = "https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en";
    static const String googleAuthenticatorAppLinkIos = "https://apps.apple.com/us/app/google-authenticator/id388497605";

    static const int paginate = 16;

    static const String signIn = '${baseUrl}api/agent/login';
    static const String signUp = '${baseUrl}api/agent/register';
    static const String countries = '${baseUrl}api/country-list';
    static const String verifyUserEmail = '${baseUrl}api/user/verify-email';
    static const String emailVerificationResendCode = '${baseUrl}api/user/resend/verify-email/code';
    static const String refreshToken = '${baseUrl}api/agent/refresh/token';
    static const String twoFaOtpVerification = '${baseUrl}api/agent/otp-submit';
    static const String user = '${baseUrl}api/agent/agent-info';
    static const String updateProfile = '${baseUrl}api/agent/profile-setting';
    static const String resetPassword = '${baseUrl}api/agent/forgot-password';
    static const String verifyEmail = '${baseUrl}api/agent/forgot-password/verify-code';
    static const String resetPasswordSubmit = '${baseUrl}api/agent/reset-password';
    static const String changePassword = '${baseUrl}api/agent/change-password';
    static const String kycForm = '${baseUrl}api/agent/kyc-form-data';
    static const String kycFormSubmit = '${baseUrl}api/agent/kyc-form';
    static const String generateQr = '${baseUrl}api/agent/generate-qrcode';
    static const String settings = '${baseUrl}api/user/settings';
    static const String module = '${baseUrl}api/module';

    static const String dashboard = '${baseUrl}api/agent/dashboard';

    //Transactions
    static String allTransactions({String? remark, String? search,required int page})=> '${baseUrl}api/agent/transactions?remark=${remark ?? ''}&search=${search ?? ''}&page=$page';

    //Withdraw
    static const String withdrawList= '${baseUrl}api/agent/withdraw-history';
    static const String withdrawFrom= '${baseUrl}api/agent/withdraw-money';
    static const String methods= '${baseUrl}api/user/withdraw-methods?currency=';
    static const String submitWithdraw= '${baseUrl}api/agent/withdraw-money';

    // CashIn
    static const String cashInFrom= '${baseUrl}api/agent/cash-in';
    static const String checkAgentReceiver= '${baseUrl}api/agent/check-user';
    static const String submitCashInRequest= '${baseUrl}api/agent/cash-in';


    //Card Withdraw
    static const String cardWithdraw= '${baseUrl}api/agent/card-withdraw';



    //Fund
    static const String fundsList= '${baseUrl}api/agent/fund-requests';
    static const String createFund= '${baseUrl}api/agent/fund-request/submit';

    // Support
    static const String tickets= '${baseUrl}api/user/support/tickets';
    static const String openTickets= '${baseUrl}api/user/open/support/ticket';
    static const String ticketMessages= '${baseUrl}api/user/support/ticket/messages/';
    static const String ticketReply= '${baseUrl}api/user/reply/ticket/';


    //2fa verification
    static const String sendCode = '${baseUrl}api/agent/two-step/send-code';
    static const String resendCode = '${baseUrl}api/agent/resend/two-step/verify-code';
    static const String enableVerification = '${baseUrl}api/agent/two-step/verification';
    static const String loginVerification = '${baseUrl}api/agent/two-step/verify';

}
