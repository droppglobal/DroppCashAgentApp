class User {
  User({
    this.id,
    this.name,
    this.username,
    this.email,
    this.photo,
    this.phone,
    this.dialCode,
    this.country,
    this.city,
    this.region,
    this.address,
    this.zip,
    this.status,
    this.emailVerified,
    this.verifyCode,
    this.password,
    this.rememberToken,
    this.twoFaStatus,
    this.twoFa,
    this.twoFaCode,
    this.nid,
    this.nidPhoto,
    this.businessName,
    this.businessAddress,
    this.createdAt,
    this.updatedAt,});

  User.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    username = json['username'];
    email = json['email'];
    photo = json['profile_photo'] ?? json['photo'];
    phone = json['phone'];
    dialCode = json['dial_code'];
    country = json['country'].toString();
    city = json['city'].toString();
    region = json['region'];
    address = json['address'];
    zip = json['zip'];
    status = json['status'].toString();
    emailVerified = json['email_verified'];
    verifyCode = json['verify_code'];
    password = json['password'];
    rememberToken = json['remember_token'];
    twoFaStatus = json['two_fa_status'];
    twoFa = json['two_fa'];
    twoFaCode = json['two_fa_code'];
    nid = json['nid'];
    nidPhoto = json['nid_photo'];
    businessName = json['business_name'];
    businessAddress = json['business_address'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }
  num? id;
  String? name;
  String? username;
  String? email;
  String? photo;
  String? phone;
  dynamic dialCode;
  String? country;
  String? city;
  String? region;
  String? address;
  String? zip;
  String? status;
  bool? emailVerified;
  dynamic verifyCode;
  String? password;
  dynamic rememberToken;
  String? twoFaStatus;
  String? twoFa;
  String? twoFaCode;
  String? nid;
  String? nidPhoto;
  String? businessName;
  String? businessAddress;
  String? createdAt;
  String? updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['username'] = username;
    map['email'] = email;
    map['photo'] = photo;
    map['phone'] = phone;
    map['dial_code'] = dialCode;
    map['country'] = country;
    map['city'] = city;
    map['region'] = region;
    map['address'] = address;
    map['zip'] = zip;
    map['status'] = status;
    map['email_verified'] = emailVerified;
    map['verify_code'] = verifyCode;
    map['password'] = password;
    map['remember_token'] = rememberToken;
    map['two_fa_status'] = twoFaStatus;
    map['two_fa'] = twoFa;
    map['two_fa_code'] = twoFaCode;
    map['nid'] = nid;
    map['nid_photo'] = nidPhoto;
    map['business_name'] = businessName;
    map['business_address'] = businessAddress;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }

}