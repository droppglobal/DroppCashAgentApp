import '../config/dependency.dart';

class Countries {
  Countries({
      this.success, 
      this.message, 
      this.response,});

  Countries.fromJson(dynamic json) {
    success = json['success'];
    message = json['message'];
    if (json['response'] != null) {
      response = [];
      json['response'].forEach((v) {
        response?.add(Country.fromJson(v));
      });
    }
  }
  bool? success;
  String? message;
  List<Country>? response;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['success'] = success;
    map['message'] = message;
    if (response != null) {
      map['response'] = response?.map((v) => v.toJson()).toList();
    }
    return map;
  }

  static Countries? getCountries(){
    try{
      return instance.get<Countries>();
    } catch(e){
      return null;
    }
  }

}

class Country {
  Country({
      this.id, 
      this.uniqueKey, 
      this.name, 
      this.code, 
      this.dialCode, 
      this.currencyId, 
      this.flag, 
      this.createdAt, 
      this.updatedAt, 
      this.cities,});

  Country.fromJson(dynamic json) {
    id = json['id'];
    uniqueKey = json['unique_key'];
    name = json['name'];
    code = json['code'];
    dialCode = json['dial_code'];
    currencyId = json['currency_id'];
    flag = json['flag'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    if (json['cities'] != null) {
      cities = [];
      json['cities'].forEach((v) {
        cities?.add(Cities.fromJson(v));
      });
    }
  }
  num? id;
  String? uniqueKey;
  String? name;
  String? code;
  String? dialCode;
  String? currencyId;
  String? flag;
  String? createdAt;
  String? updatedAt;
  List<Cities>? cities;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['unique_key'] = uniqueKey;
    map['name'] = name;
    map['code'] = code;
    map['dial_code'] = dialCode;
    map['currency_id'] = currencyId;
    map['flag'] = flag;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    if (cities != null) {
      map['cities'] = cities?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Cities {
  Cities({
      this.id, 
      this.countryId, 
      this.name, 
      this.status, 
      this.createdAt, 
      this.updatedAt, 
      this.regions,});

  Cities.fromJson(dynamic json) {
    id = json['id'];
    countryId = json['country_id'];
    name = json['name'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    if (json['regions'] != null) {
      regions = [];
      json['regions'].forEach((v) {
        regions?.add(Regions.fromJson(v));
      });
    }
  }
  num? id;
  String? countryId;
  String? name;
  String? status;
  String? createdAt;
  String? updatedAt;
  List<Regions>? regions;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['country_id'] = countryId;
    map['name'] = name;
    map['status'] = status;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    if (regions != null) {
      map['regions'] = regions?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Regions {
  Regions({
      this.id, 
      this.cityId, 
      this.name, 
      this.status, 
      this.createdAt, 
      this.updatedAt,});

  Regions.fromJson(dynamic json) {
    id = json['id'];
    cityId = json['city_id'];
    name = json['name'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }
  num? id;
  String? cityId;
  String? name;
  String? status;
  String? createdAt;
  String? updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['city_id'] = cityId;
    map['name'] = name;
    map['status'] = status;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }

}