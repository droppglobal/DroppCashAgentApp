import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:wallet_agent/Widgets/circular_progress.dart';
import 'package:wallet_agent/Widgets/show_message.dart';
import 'package:wallet_agent/data/auth.dart';
import 'package:wallet_agent/repositories/user_repository.dart';
import 'package:wallet_agent/utils/design_component.dart';
import 'package:timer_count_down/timer_controller.dart';
import 'package:timer_count_down/timer_count_down.dart';

import '../Widgets/default_button.dart';
import '../Widgets/default_textfield.dart';
import '../controllers/share_helper.dart';
import '../main.dart';
import '../routes/app_pages.dart';
import '../theme/app_color.dart';
import '../utils/dimension.dart';

class EmailVerificationChecker{
  UserRepository repository = UserRepository();

  Future checkEmailVerification(Auth auth) async {
    await repository.getSettings(
      onSuccess: (data){
        if((data.response?.isVerify ?? "0") == "1" && !(auth.response?.user?.emailVerified ?? false)){
          DesignComponent.showBottomSheetPopup(
            isScrollControlled: true,
            child: VerifyEmail(auth)
          );
        } else {
          ShareHelper.setAuth(auth);
          goAndRemoveAllPages(Routes.MAIN_PAGE);
        }
      },
      onError: (data){}
    );
  }
}

class VerifyEmail extends StatefulWidget {
  final Auth auth;
  const VerifyEmail(this.auth, {super.key});

  @override
  State<VerifyEmail> createState() => _VerifyEmailState();
}

class _VerifyEmailState extends State<VerifyEmail> {
  UserRepository repository = UserRepository();
  CountdownController countdownController =  CountdownController(autoStart: true);
  GlobalKey<FormState> formKey = GlobalKey();
  TextEditingController code = TextEditingController();
  ValueNotifier<bool> loading = ValueNotifier(false);
  ValueNotifier<bool> resendLoading = ValueNotifier(false);


  @override
  void dispose() {
    repository.close();
    countdownController.pause();
    super.dispose();
  }

  Future resendCode() async {
    resendLoading.value = true;
    await repository.resendEmailVerificationCode(
      onSuccess: (data){
        SuccessMessage(message: data['message']);
        countdownController.restart();
      },
      onError: (data){}
    );
    resendLoading.value = false;
  }

  Future verifyUserEmail() async {
    loading.value = true;
    await repository.verifyUserEmail(
      body: {
        "code": code.text
      },
      onSuccess: (data){
        ShareHelper.setAuth(widget.auth);
        goAndRemoveAllPages(Routes.MAIN_PAGE);
      },
      onError: (data){}
    );
    loading.value = false;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadiusDirectional.only(
            topEnd: Radius.circular(20.r),
            topStart: Radius.circular(20.r),
          ),
          color: AppColor.white,
        ),
        padding: REdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                16.horizontalSpace,
                Expanded(
                  child: Text(
                    appLanguage(context).verify_your_email,
                    style: appTheme(context).textTheme.headlineLarge,
                  )
                ),
                IconButton(
                    onPressed: () => backPage(),
                    icon: Icon(Icons.close_rounded, color: AppColor.iconColor)
                )
              ],
            ),
            Padding(
              padding: REdgeInsets.symmetric(horizontal: 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  8.verticalSpace,
                  Text(
                    appLanguage(context).verify_email_message,
                    style: appTheme(context).textTheme.bodyLarge,
                  ),
                  16.verticalSpace,
                  DefaultTextField(
                    controller: code,
                    backgroundColor: AppColor.textFieldBackground,
                    label: appLanguage(context).verification_code,
                    hint: appLanguage(context).verification_code,
                    labelAsTitle: true,
                  ),
                  8.verticalSpace,
                  Align(
                    alignment: Alignment.center,
                    child: ValueListenableBuilder<bool>(
                      valueListenable: resendLoading,
                      builder: (context, value, child) {
                        return Countdown(
                          controller: countdownController,
                          seconds: 60,
                          build: (_, double time){
                            return value ? CircularProgress(size: 20) : RichText(
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                    text: appLanguage(context).received_nothing,
                                    style: appTheme(context).textTheme.bodyMedium,
                                    children: [
                                      time.toInt() != 0 ? TextSpan(
                                        text: ' ${appLanguage(context).resend_code_in.replaceAll('@', '${time.toInt()}')}',
                                        style: appTheme(context).textTheme.bodyMedium,
                                      ) : TextSpan(
                                        text: ' ${appLanguage(context).resend_code}',
                                        style: appTheme(context).textTheme.bodyMedium!.copyWith(
                                            fontWeight: Dimension.textBold,
                                            decoration: TextDecoration.underline
                                        ),
                                        recognizer: TapGestureRecognizer()..onTap = () => resendCode(),
                                      )
                                    ]
                                )
                            );
                          },
                          onFinished: () {
                          },
                        );
                      }
                    ),
                  )
                ],
              ),
            ),
            16.verticalSpace,
            Padding(
              padding: REdgeInsets.symmetric(horizontal: 16),
              child: ValueListenableBuilder<bool>(
                valueListenable: loading,
                builder: (context, value, child) {
                  return DefaultButton(
                    onTap: (){
                      if(formKey.currentState!.validate()){
                        verifyUserEmail();
                      }
                    },
                    isLoading: value,
                    padding: REdgeInsets.symmetric(vertical: 14),
                    child: Container(
                      width: double.infinity,
                      alignment: Alignment.center,
                      child: Text(appLanguage(context).verify,
                        style: appTheme(context).textTheme.bodyLarge!.copyWith(
                            fontSize: 17.spMin,
                            fontWeight: Dimension.textSemiBold,
                            color: AppColor.white
                        ),
                      ),
                    ),
                  );
                }
              ),
            ),
            Dimension.bottomSpace
          ],
        ),
      ),
    );
  }
}
