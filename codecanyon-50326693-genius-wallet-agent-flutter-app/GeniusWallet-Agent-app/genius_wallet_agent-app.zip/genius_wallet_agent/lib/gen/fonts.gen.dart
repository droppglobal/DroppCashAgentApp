/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

class FontFamily {
  FontFamily._();

  /// Font family: MyFlutterApp
  static const String myFlutterApp = 'MyFlutterApp';

  /// Font family: plex_sans
  static const String plexSans = 'plex_sans';
}
