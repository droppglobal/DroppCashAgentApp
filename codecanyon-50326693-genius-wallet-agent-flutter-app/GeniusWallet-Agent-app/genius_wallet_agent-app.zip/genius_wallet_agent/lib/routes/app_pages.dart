import 'package:flutter/material.dart';
import 'package:wallet_agent/module/cash_in/view/cash_in_view.dart';
import '../module/change_password/change_password_view.dart';
import '../module/contact_us/contact_us_view.dart';
import '../module/fund_request/request_list/view/request_list_view.dart';
import '../module/kyc_verification/view/kyc_verification_view.dart';
import '../module/main_page/view/main_page_view.dart';
import '../module/my_profile/my_profile_view.dart';
import '../module/payment_page/payment_page_view.dart';
import '../module/qr_code/qr_code_view.dart';
import '../module/qr_scanner/qr_scanner_view.dart';
import '../module/reset_password/view/reset_password_view.dart';
import '../module/sign_in/view/sign_in_view.dart';
import '../module/sign_up/view/sign_up_view.dart';
import '../module/splash/splash_view.dart';
import '../module/support/support_details/view/support_details_view.dart';
import '../module/support/support_list/view/support_list_view.dart';
import '../module/transactions/transaction_list/view/transaction_list_view.dart';
import '../module/two_fa_verification/view/two_fa_verification_view.dart';
import '../module/withdraw/withdraw_history/view/withdraw_history_view.dart';
import '../module/withdraw/withdraw_money/view/withdraw_money_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH;

  static Map<String, WidgetBuilder> routes = {
    INITIAL : (context) => SplashPage(),
    Routes.SIGN_IN : (context) => SignInPage(),
    Routes.SIGN_UP : (context) => SignUpPage(),
    Routes.KYC_VERIFICATION : (context) => KycVerificationPage(),
    Routes.MAIN_PAGE : (context) => MainPage(),
    Routes.EDIT_PROFILE : (context) => MyProfilePage(),
    Routes.CHANGE_PASSWORD : (context) => ChangePasswordPage(),
    Routes.RESET_PASSWORD : (context) => ResetPasswordPage(),
    Routes.CONTACT_US : (context) => ContactUsPage(),
    Routes.WITHDRAW_LIST : (context) => WithdrawHistoryPage(),
    Routes.ADD_WITHDRAW : (context) => WithdrawMoneyPage(),
    Routes.PAYMENT_PAGE : (context) => PaymentPagePage(),
    Routes.TWO_FA_VERIFICATION : (context) => TwoFAVerificationPage(),
    Routes.TRANSACTIONS : (context) => TransactionListPage(),
    Routes.SUPPORT_PAGES : (context) => SupportListPage(),
    Routes.SUPPORT_DETAILS : (context) => SupportDetailsPage(),
    Routes.QR_PAGE : (context) => QrCodePage(),
    Routes.QR_SCANNER_PAGE : (context) => QrScannerPage(),
    Routes.FUND_REQUEST_LIST : (context) => RequestListPage(),
    Routes.CASH_IN : (context) => CashInPage(),
  };
}
