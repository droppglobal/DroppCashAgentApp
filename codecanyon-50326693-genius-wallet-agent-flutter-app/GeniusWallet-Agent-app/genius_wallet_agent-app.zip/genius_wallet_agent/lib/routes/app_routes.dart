part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const SPLASH = '/';
  static const MAIN_PAGE = '/main-page';
  static const SIGN_IN = '/sign-in';
  static const SIGN_UP = '/sign-up';
  static const KYC_VERIFICATION = '/kyc-verification';
  static const EDIT_PROFILE = '/edit-profile';
  static const CHANGE_PASSWORD = '/change-password';
  static const RESET_PASSWORD = '/reset-password';
  static const SUPPORT_PAGES = '/support-pages';
  static const SUPPORT_DETAILS = '/support-details';
  static const CONTACT_US = '/contact-us';
  static const WITHDRAW_LIST = '/withdraw-list';
  static const ADD_WITHDRAW = '/add-withdraw';
  static const PAYMENT_PAGE = '/payment-page';
  static const TRANSACTIONS = '/transactions';
  static const TWO_FA_VERIFICATION = '/two-fa-verification';
  static const QR_PAGE = '/qr-page';
  static const QR_SCANNER_PAGE = '/qr-scanner-page';
  static const FUND_REQUEST_LIST = '/fund-request-list';
  static const CASH_IN = '/cash-in';
}
