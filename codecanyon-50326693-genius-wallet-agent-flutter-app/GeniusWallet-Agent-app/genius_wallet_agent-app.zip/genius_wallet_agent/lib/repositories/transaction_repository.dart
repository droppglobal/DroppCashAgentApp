import 'package:wallet_agent/module/transactions/transaction_list/data/transactions.dart';

import '../app_helper/api_client.dart';
import '../utils/url.dart';

class TransactionRepository{
  ApiClient apiClient = ApiClient();

  void close(){
    apiClient.close();
  }

  Future getTransactions({required String? url,required Function(Transactions) onSuccess,required Function(Map<String,dynamic>) onError,}) async {
    await apiClient.Request(
      url: url ?? URL.allTransactions(page: 1),
      onSuccess: (Map<String,dynamic> data) {
        Transactions deposit = Transactions.fromJson(data);
        onSuccess(deposit);
      },
      onError: onError
    );
  }
}