import 'package:wallet_agent/module/cash_in/data/receiver_check.dart';
import '../app_helper/api_client.dart';
import '../module/cash_in/data/request_money_data.dart';
import '../utils/url.dart';

class TransferRepository{
  ApiClient apiClient = ApiClient();

  void close(){
    apiClient.close();
  }


  Future changeRequestMoneyStatus({required String url, required Map<String, String> body, required Function(Map<String,dynamic>) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
      url: url,
      body: body,
      method: Method.POST,
      onSuccess: (Map<String,dynamic> data) {
        onSuccess(data);
      },
      onError: onError
    );
  }


  Future getRequestMoneyFrom({required Function(RequestMoneyData) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
      url: URL.cashInFrom,
      onSuccess: (Map<String,dynamic> data) {
        RequestMoneyData banks = RequestMoneyData.fromJson(data);
        onSuccess(banks);
      },
      onError: onError
    );
  }

  Future checkReceiver({required String email,required Function(ReceiverCheck) onSuccess,required Function(ReceiverCheck) onError}) async {
    await apiClient.Request(
      url: URL.checkAgentReceiver,
      method: Method.POST,
      body: {
        'receiver': email
      },
      enableShowError: false,
      onSuccess: (Map<String,dynamic> data) {
        onSuccess(ReceiverCheck.fromJson(data));
      },
      onError: (data)=>onError(ReceiverCheck.fromJson(data))
    );
  }

  Future submitRequest({required Map<String,String> body,required Function(Map<String,dynamic>) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
      url: URL.submitCashInRequest,
      method: Method.POST,
      body: body,
      onSuccess: (Map<String,dynamic> data) {
        onSuccess(data);
      },
      onError: onError
    );
  }

  Future cardWithdraw({required Map<String,String> body,required Function(Map<String,dynamic>) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
      url: URL.cardWithdraw,
      method: Method.POST,
      body: body,
      onSuccess: (Map<String,dynamic> data) {
        onSuccess(data);
      },
      onError: onError
    );
  }



}