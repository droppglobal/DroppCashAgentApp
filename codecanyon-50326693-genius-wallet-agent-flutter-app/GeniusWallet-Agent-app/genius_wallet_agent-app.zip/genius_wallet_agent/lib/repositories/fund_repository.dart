
import 'package:wallet_agent/module/fund_request/request_list/data/fund_list.dart';

import '../app_helper/api_client.dart';
import '../utils/url.dart';

class FundRepository{
  ApiClient apiClient = ApiClient();

  void close(){
    apiClient.close();
  }

  Future getFundList({String? url, required Function(FundList) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
      url: url ?? URL.fundsList,
      onSuccess: (Map<String,dynamic> data) {
        FundList transfers = FundList.fromJson(data);
        onSuccess(transfers);
      },
      onError: onError
    );
  }


  Future submitFundData({required Map<String, String> body, required Function(Map<String, dynamic>) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
      url: URL.createFund,
      method: Method.POST,
      body: body,
      onSuccess: (Map<String,dynamic> data) {
        onSuccess(data);
      },
      onError: onError
    );
  }

}