import 'package:wallet_agent/data/module.dart';

import '../app_helper/api_client.dart';
import '../config/dependency.dart';
import '../data/countries.dart';
import '../utils/url.dart';

class SplashRepository{
  ApiClient apiClient = ApiClient();

  void close(){
    apiClient.close();
  }

  Future getModuleData({required Function(Module) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
        url: URL.module,
        withAuth: false,
        onSuccess: (Map<String,dynamic> data) {
          Module transfers = Module.fromJson(data);
          instance.registerSingleton<Module>(transfers);
          onSuccess(transfers);
        },
        onError: onError
    );
  }
  Future getCountries({required Function(Countries) onSuccess,required Function(Map<String,dynamic>) onError}) async {
    await apiClient.Request(
        url: URL.countries,
        withAuth: false,
        onSuccess: (Map<String,dynamic> data) {
          Countries countries = Countries.fromJson(data);
          instance.registerSingleton<Countries>(countries);
          onSuccess(countries);
        },
        onError: onError
    );
  }
}