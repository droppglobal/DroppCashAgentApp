package com.example.wallet_agent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
